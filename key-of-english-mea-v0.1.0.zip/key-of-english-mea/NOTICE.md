# Notice

Key of English and Median-Extremes Alternation materials are attributed to David Carr. This package is a working AI-skill implementation of the July 2026 bootloader and is not a declaration that any external historical, scientific, philosophical, or theological claim has been independently established.

The parser fixes mechanical reproduction of the published glyph mapping and MEA sequence. Interpretive compressions remain accountable to the exact circuit, the Anglophone-paradigm boundary, historical provenance, and reality-contact.
