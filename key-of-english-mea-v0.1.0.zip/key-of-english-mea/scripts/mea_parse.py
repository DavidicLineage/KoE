#!/usr/bin/env python3
"""Deterministic Key of English / MEA parser.

This script computes engagement order only. It does not perform interpretive
compression. It is dependency-free and emits either human-readable text or JSON.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import dataclass, asdict
from typing import Iterable

PRIMITIVES: dict[str, str] = {
    "A": "vehicle",
    "B": "tension",
    "C": "subjective",
    "D": "broken cycle",
    "E": "measure",
    "F": "immeasurable",
    "G": "effort",
    "H": "union",
    "I": "mastery",
    "J": "edit",
    "K": "strike",
    "L": "profit",
    "M": "mass",
    "N": "seed",
    "O": "whole cycle",
    "P": "potential",
    "Q": "marked cycle",
    "R": "result",
    "S": "redirect",
    "T": "sacrifice",
    "U": "transient",
    "V": "hand",
    "W": "choice",
    "X": "decision",
    "Y": "convergence",
    "Z": "interval",
}

WORD_RE = re.compile(r"[A-Za-z]+")


@dataclass(frozen=True)
class Unit:
    glyphs: str
    indices: tuple[int, ...]
    primitives: tuple[str, ...]


@dataclass(frozen=True)
class WordParse:
    original: str
    normalized: str
    units: tuple[Unit, ...]


def _unit(word: str, indices: Iterable[int]) -> Unit:
    idx = tuple(indices)
    glyphs = "".join(word[i] for i in idx)
    return Unit(
        glyphs=glyphs,
        indices=idx,
        primitives=tuple(PRIMITIVES[g] for g in glyphs),
    )


def parse_word(raw_word: str) -> WordParse:
    """Parse one ASCII A-Z lexical word using deterministic MEA order."""
    if not raw_word:
        raise ValueError("word is empty")
    if not re.fullmatch(r"[A-Za-z]+", raw_word):
        raise ValueError(
            f"{raw_word!r} is not one A-Z lexical word. "
            "Preserve lexical boundaries and pass words separately."
        )

    word = raw_word.upper()
    n = len(word)
    unused = list(range(n))
    units: list[Unit] = []

    # Center engagement.
    if n % 2:
        center = n // 2
        units.append(_unit(word, (center,)))
        unused.remove(center)
    else:
        left = n // 2 - 1
        right = n // 2
        units.append(_unit(word, (left, right)))
        unused.remove(left)
        unused.remove(right)

    take_outer = True
    while unused:
        if len(unused) == 1:
            # Defensive only; after center removal, valid words leave an even count.
            units.append(_unit(word, (unused.pop(),)))
            break

        if take_outer:
            left = unused.pop(0)
            right = unused.pop(-1)
        else:
            mid_left = len(unused) // 2 - 1
            left = unused.pop(mid_left)
            # After removing left, the matching right member occupies mid_left.
            right = unused.pop(mid_left)

        units.append(_unit(word, (left, right)))
        take_outer = not take_outer

    return WordParse(original=raw_word, normalized=word, units=tuple(units))


def parse_phrase(text: str) -> list[WordParse]:
    """Parse each A-Z lexical word independently, preserving occurrence order."""
    words = WORD_RE.findall(text)
    if not words:
        raise ValueError("input contains no A-Z lexical words")
    return [parse_word(word) for word in words]


def to_jsonable(parsed: list[WordParse]) -> dict[str, object]:
    return {
        "system": "Key of English / Median-Extremes Alternation",
        "words": [
            {
                **asdict(word),
                "sequence": [unit.glyphs for unit in word.units],
                "primitive_chain": [
                    list(unit.primitives) if len(unit.primitives) > 1 else unit.primitives[0]
                    for unit in word.units
                ],
            }
            for word in parsed
        ],
    }


def format_text(parsed: list[WordParse]) -> str:
    blocks: list[str] = []
    for word in parsed:
        seq = " / ".join(unit.glyphs for unit in word.units)
        primitive_units = []
        for unit in word.units:
            primitive_units.append(" + ".join(unit.primitives))
        primitives = " / ".join(primitive_units)
        blocks.append(
            f"{word.normalized}\n"
            f"MEA: {seq}\n"
            f"Primitives: {primitives}"
        )
    return "\n\n".join(blocks)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Compute the deterministic KoE/MEA engagement sequence."
    )
    parser.add_argument("text", help="One word or a phrase; words parse independently.")
    parser.add_argument(
        "--json", action="store_true", help="Emit structured JSON instead of text."
    )
    args = parser.parse_args()

    try:
        parsed = parse_phrase(args.text)
    except ValueError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2

    if args.json:
        print(json.dumps(to_jsonable(parsed), indent=2, ensure_ascii=False))
    else:
        print(format_text(parsed))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
