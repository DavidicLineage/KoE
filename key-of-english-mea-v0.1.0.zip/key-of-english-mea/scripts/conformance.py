#!/usr/bin/env python3
"""Exact mechanical conformance checks for the KoE/MEA parser."""

from __future__ import annotations

from mea_parse import parse_word

CASES: dict[str, list[str]] = {
    "DEGREE": ["GR", "DE", "EE"],
    "THE": ["H", "TE"],
    "VALUE": ["L", "VE", "AU"],
    "WORTH": ["R", "WH", "OT"],
    "BOUND": ["U", "BD", "ON"],
    "RAIN": ["AI", "RN"],
    "REIN": ["EI", "RN"],
    "REIGN": ["I", "RN", "EG"],
    "DAY": ["A", "DY"],
    "DATE": ["AT", "DE"],
    "DATELINE": ["EL", "DE", "TI", "AN"],
    "DEFINE": ["FI", "DE", "EN"],
    "DEFINITION": ["NI", "DN", "IT", "EO", "FI"],
    "SUPERMAN": ["ER", "SN", "PM", "UA"],
}


def main() -> int:
    failures: list[str] = []
    for word, expected in CASES.items():
        actual = [unit.glyphs for unit in parse_word(word).units]
        if actual != expected:
            failures.append(f"{word}: expected {expected}, got {actual}")
        else:
            print(f"PASS  {word:<10} {' / '.join(actual)}")

    if failures:
        print("\nCONFORMANCE FAILURE")
        for failure in failures:
            print(f"- {failure}")
        return 1

    print(f"\nAll {len(CASES)} mechanical cases conform.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
