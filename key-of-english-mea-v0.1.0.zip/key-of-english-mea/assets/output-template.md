# KoE / MEA analysis

## [EXACT WORD]

**MEA:** `[ordered sequence]`

**Primitives:** [ordered primitive chain]

**Mechanics:** [neutral directed reading]

**Compression:** [narrow operational invariant]

**Orientations / applications:** [only where relevant]

**Diagnostic:** [what the current use performs or fails to perform]

**Layer note:** [Anglophone encoding / historical lineage / reality-contact]
