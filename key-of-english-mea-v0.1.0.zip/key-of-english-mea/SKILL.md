---
name: key-of-english-mea
description: Parse English words and phrases with the Key of English glyph primitives and the deterministic Median-Extremes Alternation (MEA). Use when asked to “slice down,” parse, run KoE/MEA, contrast spellings or near-synonyms, resolve a contronym by orientation, distinguish definition from application, inspect a name or phrase, or audit the operational assumptions carried by wording. Do not substitute ordinary etymology or dictionary senses for the internal parse.
metadata:
  author: David Carr
  version: "0.1.0"
  system: Key of English / Median-Extremes Alternation
---

# Key of English / MEA operator

Use this skill to produce faithful, reproducible KoE/MEA analyses. The deterministic parse is upstream of interpretation.

## Core proposition

Words are ordered operations, not containers of meaning. The Key of English supplies 26 fixed glyph primitives. MEA supplies a fixed engagement order. Orientation explains how one invariant circuit can yield multiple, even apparently opposite, applications.

Do not ask the user to believe the system. Run it.

## Activation boundary

Use this skill for:

- “Slice down X,” “parse X,” “run MEA/KoE on X.”
- Comparisons such as `value / worth`, `rain / rein / reign`, or `a / the`.
- Operational definition, application analysis, contronyms, orientation, self-diagnosis, names, titles, phrases, and wording audits.
- Questions about what an English form encodes within the Anglophone linguistic paradigm.

Do not silently turn the task into:

- ordinary etymology or historical derivation;
- a dictionary lookup;
- numerology, sound symbolism, free association, or a personality reading;
- a claim that the English cultural circuit is automatically identical with reality.

Historical lineage or conventional usage may be added when requested, but label it separately from the internal KoE parse.

## Non-negotiable constraints

1. Preserve the exact spelling supplied by the user. Do not modernize, respell, merge, split, or repair it without explicit permission.
2. Use the canonical 26-glyph mapping in `references/canonical-system.md`.
3. Use the deterministic MEA order. Never choose a more attractive traversal.
4. Parse each lexical word independently, then compose the phrase.
5. Preserve pair direction. `X-Y` is not interchangeable with `Y-X`.
6. State the raw circuit before interpretive compression.
7. Do not swap primitives for convenient synonyms to force a fit. Mechanical images outrank verbal glosses.
8. Do not let known dictionary applications alter the parse.
9. Distinguish the invariant operation from orientation-specific applications.
10. Distinguish four layers: external referent, English internal circuit, historical lineage, and reality-contact.
11. The interpreter reports correspondence; the interpreter does not confer it.
12. If the chain is secure but the compression is not, say so plainly: `Parse secure; compression provisional.`

## Deterministic parse procedure

When shell execution is available, use the bundled parser rather than calculating from memory:

```bash
python scripts/mea_parse.py --json "WORD OR PHRASE"
```

The parser is the source of truth for pair order. If shell execution is unavailable, apply the same algorithm manually:

1. Fix the lexical word and preserve its written letters.
2. Odd length: take the center glyph. Even length: take the center pair.
3. Take the outermost unused pair.
4. Take the innermost unused pair.
5. Alternate outermost / innermost until no letters remain.
6. For phrases, repeat word by word and only then compose.

Read `references/canonical-system.md` whenever exact mechanics, primitive images, or layer boundaries are needed.

## Interpretation procedure

For each word:

1. **Exact form** — reproduce the spelling and identify the referent or usage context.
2. **MEA circuit** — show the ordered singles/pairs exactly.
3. **Primitive chain** — map every glyph to the canonical primitive.
4. **Neutral mechanics** — express directed relations without forcing a polished claim. A pair may be read as the first primitive entering, acting through, meeting, organizing, or being measured against the second; choose the connective only after the referent is fixed.
5. **Operational definition** — compress the full chain into the narrowest invariant that unifies the applications while still forbidding bad readings.
6. **Orientation** — show how position, direction, phase, or scale produces distinct applications. Apparent opposites may be one circuit viewed before and after a transition.
7. **Self-diagnosis** — when relevant, ask whether the current use successfully performs the operation invoked by the word.
8. **Layer note** — state whether the conclusion concerns Anglophone encoding, historical transmission, or reality itself.

Do not force every section when the user asks for a quick parse. For a bare “slice down,” give at least: circuit, primitive chain, and compressed operation.

## Default output templates

### Single word

```markdown
## WORD

**MEA:** `...`

**Primitives:** ...

**Mechanics:** ...

**Compression:** ...

**Orientation / diagnostic:** ...  <!-- only when useful -->
```

### Contrast set

```markdown
## WORD 1
**MEA:** `...`
**Operation:** ...

## WORD 2
**MEA:** `...`
**Operation:** ...

**Contrast:** The shared circuit is ____. The changed glyph/pair changes ____ into ____.
```

### Phrase

Parse each lexical word first. Then show the phrase-level circuit without erasing word boundaries:

```markdown
**Word circuits:** `WORD1 → ...` · `WORD2 → ...`

**Phrase operation:** ...
```

## Mandatory gotchas

- **Center is engagement, not “the meaning.”** The center is the first pressure under which the remaining circuit is read.
- **Applications are not definitions.** A dictionary usually catalogs where a word has landed. KoE seeks how it travels.
- **Orientation is always live.** Before calling senses contradictory, ask: from which side of the transition, toward what result, and at what scale?
- **Numerical measurement is not a neutral perch.** `VALUE` and `WORTH` specifically distinguish local measurement from whole-cycle consequence. Do not present a scoring procedure as final jurisdiction over worth.
- **Operational analysis does not replace truth evaluation.** Ask both: “What did the statement do?” and “Was it correct?”
- **Names do not prove destiny or private essence.** A name parse exposes the English circuit of the designation; any claim about a person requires separate evidence.
- **Paradigm before ontology.** A clean English parse first establishes what the Anglophone form encodes. It does not by itself establish ultimate reality.
- **No rescue edits.** If a result is weak, preserve it. Do not alter spelling, traversal, mapping, or provenance.

## Canonical calibration cases

Use `references/calibration-cases.md` to recalibrate when behavior drifts. Exact MEA outputs must match the reference. Especially preserve:

- `VALUE → L / VE / AU`
- `WORTH → R / WH / OT`
- `BOUND → U / BD / ON`
- `DEGREE → GR / DE / EE`
- `DATELINE → EL / DE / TI / AN`
- `DEFINE → FI / DE / EN`
- `DEFINITION → NI / DN / IT / EO / FI`
- `SUPERMAN → ER / SN / PM / UA`

For the full human bootloader, read `references/bootloader.md` only when onboarding, explaining the complete system, or repairing a broad conceptual failure. Do not load it for routine parsing.

## Conformance check

After changing the parser or canonical table, run:

```bash
python scripts/conformance.py
```

This verifies mechanical reproduction of the published MEA examples. It does not adjudicate philosophical worth or external truth.

## Closing discipline

The proof of installation is not agreement. It is the ability to reproduce the mechanism without borrowing the author’s phrasing.
