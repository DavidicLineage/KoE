# Canonical KoE / MEA system reference

## 26 glyph primitives

The verbal primitive is subordinate to the mechanical image. Do not expand a primitive so broadly that it ceases to constrain interpretation.

| Glyph | Image | Primitive | Operational pressure |
|---|---|---|---|
| A | ladder | **vehicle** | carry, ascend, transport |
| B | bow and arrow | **tension** | drawn force, stored release |
| C | crescent | **subjective** | open curve, partial reception |
| D | saddle / broken loop | **broken cycle** | interruption, dismount, breach |
| E | gradient / steps | **measure** | tier, calibration, distinction |
| F | ungrounded stroke | **immeasurable** | floating, unbased, unbounded |
| G | counterclockwise turn | **effort** | labour, torque against resistance |
| H | mortar / bridge | **union** | join, bind, hold together |
| I | pedestal / axis | **mastery** | upright control, operative centre |
| J | hook | **edit** | catch, pull, alter the line |
| K | impact geometry | **strike** | confront, collide, cut across |
| L | continued line | **profit** | extension, gain, carried-forward result |
| M | double peak / load | **mass** | weight, accumulation, encumbrance |
| N | seed / germ | **seed** | origin, reproduction, next instance |
| O | circle | **whole cycle** | closure, enclosure, completed field |
| P | pregnancy / contained curve | **potential** | held possibility, not-yet-result |
| Q | scored circle | **marked cycle** | noted whole, cycle with a cut |
| R | birth from P | **result** | delivery, outcome, emergence |
| S | double curve / polarity | **redirect** | flow shift, reversal, reorientation |
| T | cross / yardarm | **sacrifice** | cost, intersection, expenditure |
| U | cup / vessel | **transient** | temporary holding, passing state |
| V | hand / lifted point | **hand** | agent, grasp, directed contact |
| W | valleys and peaks | **choice** | branching alternatives, selection |
| X | crossroads | **decision** | paths made mutually exclusive |
| Y | fork meeting stem | **convergence** | separate paths becoming one |
| Z | angular drop / gap | **interval** | separation, break, span |

## MEA engagement order

MEA is deterministic. The operator does not choose which letters to pair.

1. Normalize a lexical word to its written A–Z letters while preserving spelling.
2. Odd length: take the center glyph.
3. Even length: take the center pair, left-to-right.
4. Take the outermost unused pair, left-to-right.
5. Take the innermost unused pair, left-to-right.
6. Alternate outermost / innermost until the word is spent.
7. Parse phrases word-by-word, then compose.

### Example: SUPERMAN

Letters and indices:

`S0 U1 P2 E3 R4 M5 A6 N7`

- center pair: `ER`
- outermost unused: `SN`
- innermost unused: `PM`
- outermost unused: `UA`

Result: `ER / SN / PM / UA`

## Directed composition

A pair is a directed relation, not a new dictionary entry. Preserve order.

Read `X-Y` as X entering, acting through, meeting, organizing, or being measured against Y. The lawful connective depends on the referent; pair order does not.

Three levels of reading:

1. **Primitive chain:** state the exact singles/pairs without embellishment.
2. **Neutral mechanics:** express the directed relations while preserving uncertainty.
3. **Referential compression:** identify the invariant operation that explains the applications.

## Definition and application

- **Definition:** the invariant generative operation.
- **Application:** an orientation-specific output or use of that operation.

A proposed definition must unify applications without erasing their differences. If it fits only one usage, it is another application. If it fits everything because it forbids nothing, return to the primitive chain.

## Orientation

Orientation includes position, direction, phase, and scale. A single circuit can appear as confinement from one side of a transition and propulsion from the other.

Before declaring contradiction, ask:

- From which position is the operation observed?
- Toward which transition or result?
- Before or after the break?
- At instantiation or lineage scale?

## Self-diagnosis

A word can inspect its own use because the application can be compared with the encoded operation. A mismatch is a fault report.

This does not make criticism invalid. The examiner is also inside the linguistic field:

1. What operation did the criticism perform?
2. Was the criticism factually or logically correct?

Both questions remain necessary.

## Layer discipline

Keep these layers distinct:

1. **External usage:** referent and application field.
2. **Internal parse:** operational pressure encoded in the English form.
3. **Historical lineage:** what the receiving language borrowed, altered, or misattributed.
4. **Reality-contact:** whether the encoded assumption is faithful, partial, adaptive, or false.

The circuitry first retains authority over attribution within the Anglophone paradigm. The interpreter reports correspondence; the interpreter does not create it.
