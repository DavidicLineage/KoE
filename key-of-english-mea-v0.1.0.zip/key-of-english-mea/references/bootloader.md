**KEY OF ENGLISH**

**MEA BOOTLOADER**

*An operational installation for competent readers*

<img src="media/image1.png" style="width:3.35in;height:3.32599in" />

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>BOOT PROPOSITION<br />
Words are not containers of meaning. They are ordered operations whose applications can be inspected against the circuitry that produced them.</strong></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

**DO NOT BELIEVE THIS DOCUMENT. RUN IT.**

David Carr · July 2026 · Working Draft v0.1

**START HERE**

Boot target

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>SYSTEM IN ONE SENTENCE<br />
The Key of English supplies a fixed alphabetic parts list. MEA supplies a fixed order of engagement. Orientation explains why one circuit can generate multiple, even opposite, applications.</strong></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

This is a bootloader, not an encyclopedia. Its job is to install enough of the mechanism that a reader can operate it without borrowing the author’s conclusions. By the final page, the reader should be able to run a word, preserve the parse, rotate orientation, distinguish a definition from its applications, and detect when a usage contradicts the operation that authorizes it.

Four distinctions must survive installation

**• Key of English:** the 26 glyph roles - the teeth of the system.

**• MEA:** the deterministic center/extremes oscillation that orders those teeth.

**• Definition:** the invariant operation that generates a family of applications.

**• Orientation:** the position, direction, or scale from which the same operation is observed.

What this document does not ask you to grant

• It does not ask you to treat the interpreter as sovereign over the mechanism.

• It does not claim that every cultural assumption encoded in English is identical with reality.

• It does not allow the parser to change its order to rescue a desired result.

• It does not confuse institutional recognition with correspondence.

The boot sequence

| **STAGE** | **INSTALLATION**                     |
|-----------|--------------------------------------|
| **01**    | Load the 26 primitives.              |
| **02**    | Install the MEA oscillation.         |
| **03**    | Learn directed pair composition.     |
| **04**    | Separate operation from application. |
| **05**    | Rotate orientation.                  |
| **06**    | Use words as self-diagnostics.       |
| **07**    | Run a new word without assistance.   |

**LOAD THE PARTS LIST**

Glyph table I

The primitive is not a dictionary definition of the letter. It is the recurring operational pressure carried by the glyph in the Anglophone paradigm. The image is the mnemonic that keeps the primitive mechanical rather than merely verbal.

| **GLYPH** | **IMAGE**             | **PRIMITIVE** | **OPERATIONAL PRESSURE**                  |
|-----------|-----------------------|---------------|-------------------------------------------|
| **A**     | Ladder                | VEHICLE       | carry · ascend · transport                |
| **B**     | Bow and arrow         | TENSION       | drawn force · stored release              |
| **C**     | Crescent              | SUBJECTIVE    | open curve · partial reception            |
| **D**     | Saddle / broken loop  | BROKEN CYCLE  | interruption · dismount · breach          |
| **E**     | Gradient / steps      | MEASURE       | tier · calibration · distinction          |
| **F**     | Ungrounded stroke     | IMMEASURABLE  | floating · unbased · unbounded            |
| **G**     | Counterclockwise turn | EFFORT        | labor · torque against resistance         |
| **H**     | Mortar / bridge       | UNION         | join · bind · hold together               |
| **I**     | Pedestal / axis       | MASTERY       | upright control · operative center        |
| **J**     | Hook                  | EDIT          | catch · pull · alter the line             |
| **K**     | Impact geometry       | STRIKE        | confront · collide · cut across           |
| **L**     | Continued line        | PROFIT        | extension · gain · carried-forward result |
| **M**     | Double peak / load    | MASS          | weight · accumulation · encumbrance       |

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>LOAD DISCIPLINE<br />
Do not memorize synonyms. Memorize the mechanical image and let the vocabulary remain subordinate to it.</strong></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

**COMPLETE THE PARTS LIST**

Glyph table II

| **GLYPH** | **IMAGE**                   | **PRIMITIVE** | **OPERATIONAL PRESSURE**              |
|-----------|-----------------------------|---------------|---------------------------------------|
| **N**     | Seed / germ                 | SEED          | origin · reproduction · next instance |
| **O**     | Circle                      | WHOLE CYCLE   | closure · enclosure · completed field |
| **P**     | Pregnancy / contained curve | POTENTIAL     | held possibility · not-yet-result     |
| **Q**     | Scored circle               | MARKED CYCLE  | noted whole · cycle with a cut        |
| **R**     | Birth from P                | RESULT        | delivery · outcome · emergence        |
| **S**     | Double curve / polarity     | REDIRECT      | flow shift · reversal · reorientation |
| **T**     | Cross / yardarm             | SACRIFICE     | cost · intersection · expenditure     |
| **U**     | Cup / vessel                | TRANSIENT     | temporary holding · passing state     |
| **V**     | Hand / lifted point         | HAND          | agent · grasp · directed contact      |
| **W**     | Valleys and peaks           | CHOICE        | branching alternatives · selection    |
| **X**     | Crossroads                  | DECISION      | paths made mutually exclusive         |
| **Y**     | Fork meeting stem           | CONVERGENCE   | separate paths becoming one           |
| **Z**     | Angular drop / gap          | INTERVAL      | separation · break · span             |

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>FAULT RECOVERY<br />
A primitive is useful only if it constrains interpretation. When in doubt, return to the image and preserve the letter order.</strong></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

**INSTALL THE OSCILLATION**

MEA: the engagement order

MEA is deterministic. The operator does not choose which letters to pair. It begins at the median, jumps to the extremes, then alternates between the next unused pair nearest the center and the next unused pair nearest the outside until the word is spent.

<img src="media/image2.png" style="width:6.9in;height:3.63361in" />

Algorithm

| **STEP** | **INSTRUCTION**                                                       |
|----------|-----------------------------------------------------------------------|
| **1**    | Normalize the lexical word to its written letters. Preserve spelling. |
| **2**    | Odd length: take the center glyph. Even length: take the center pair. |
| **3**    | Take the outermost unused pair.                                       |
| **4**    | Take the innermost unused pair.                                       |
| **5**    | Alternate outermost / innermost until no letters remain.              |
| **6**    | For phrases, parse each lexical word independently, then compose.     |

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>NON-NEGOTIABLE<br />
The order is fixed. Interpretation begins after the parse, never before it.</strong></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

**MAKE THE GEARS MESH**

Pair composition and orientation

MEA outputs a chain of single primitives and ordered pairs. A pair is a directed relation, not a new dictionary entry. Read X-Y as X entering, acting through, meeting, organizing, or being measured against Y. The connective changes with the referent; the order does not.

| **WORD / MEA** | **BOUND → U / BD / ON**                                 |
|----------------|---------------------------------------------------------|
| **PRIMITIVES** | transient / tension + broken cycle / whole cycle + seed |

Three levels of reading

**• Primitive chain:** state the output without embellishment.

**• Neutral mechanics:** express the relations while preserving order and uncertainty.

**• Referential compression:** identify the invariant operation that explains the word’s applications.

The center is not “the meaning”

The center is the engagement point: the first pressure under which the rest of the word is read. The outermost pair supplies the broad rails or field. Later pairs refine, qualify, or resolve the operation. Long words are not bags of symbols; they are timed sequences.

Orientation is always live

The same circuit can appear as confinement from one side of a transition and propulsion from the other. Before declaring contradiction, ask: from which position, toward which transition, and at what scale is this application being observed?

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>OPERATOR POSTURE<br />
Do not force a polished sentence too early. Preserve the chain until the referent reveals the lawful connective.</strong></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

**FIRST FULL BOOT**

Definition versus application

| **WORD / MEA** | **DEGREE → GR / DE / EE**                                                      |
|----------------|--------------------------------------------------------------------------------|
| **PRIMITIVES** | effort + result / broken cycle + measure / measure + measure                   |
| **OPERATION**  | **Effort’s result; a broken cycle measured; a measure placed among measures.** |

A dictionary lists an academic qualification, an angle, temperature, rank, and extent. Those are applications. The parse recovers the invariant that permits them to belong to one word: a field is divided or ordered, and a position within it is measured or conferred.

| **APPLICATION**         | **OPERATIONAL CONTINUITY**                                    |
|-------------------------|---------------------------------------------------------------|
| **Academic degree**     | Effort produces a result located within an authorized scale.  |
| **Geometric degree**    | A cycle is divided and one measured position is named.        |
| **Temperature degree**  | A state is located along a calibrated series of measures.     |
| **Degree of intensity** | A phenomenon is placed within an ordered field of comparison. |

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>CORE DISTINCTION<br />
The dictionary catalogs where the word has landed. The Key identifies how it travels.</strong></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

Installation check

A definition should unify the applications without erasing their differences. If the proposed invariant fits only one usage, it is another application. If it fits everything because it forbids nothing, return to the primitive chain.

**ARTICLES AND PREPOSITIONS**

The small words are machinery

| **WORD** | **MEA** | **PRIMITIVE CHAIN**         | **OPERATION**                                                                     |
|----------|---------|-----------------------------|-----------------------------------------------------------------------------------|
| **A**    | A       | vehicle                     | Presents one admissible instance without claiming exhaustive identity.            |
| **THE**  | H / TE  | union / sacrifice + measure | Unites the field, sacrifices alternatives, and measures one determinate referent. |
| **ON**   | ON      | whole cycle + seed          | The seed is supported or conveyed by an operating field.                          |
| **IN**   | IN      | mastery + seed              | The seed is contained, compressed, and shaped within a governing field.           |

Operational contrasts

| **CONTRAST**                    | **MECHANICAL DIFFERENCE**                                           |
|---------------------------------|---------------------------------------------------------------------|
| **a model / the model**         | Presentation of an instance / installation of a governing referent. |
| **on the water / in the water** | Conveyed by the medium / contained and governed by it.              |
| **on my mind / in my mind**     | Moving through attention / held within the cognitive field.         |
| **on the team / in the team**   | Participation in the active cycle / position inside its structure.  |

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>PRECISION RULE<br />
Alter the article or preposition and you do not get a blurrier thought. You get a different operation wearing the same nouns.</strong></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

**THE MEASURING HAND ENTERS THE SLIDE**

Value is not worth

| **WORD / MEA** | **VALUE → L / VE / AU**                                 |
|----------------|---------------------------------------------------------|
| **PRIMITIVES** | profit / hand + measure / vehicle + transient           |
| **OPERATION**  | **Profit measured by a hand upon a transient vehicle.** |

| **WORD / MEA** | **WORTH → R / WH / OT**                                                        |
|----------------|--------------------------------------------------------------------------------|
| **PRIMITIVES** | result / choice + union / whole cycle + sacrifice                              |
| **OPERATION**  | **The result of choices united with their sacrifices across the whole cycle.** |

A score can assign value. It selects a hand, a measure, a vehicle, and a time horizon. That can be useful. It cannot settle worth, because worth includes the choices, exclusions, costs, consequences, and completed cycle that the score compresses or discards.

Before accepting any score, ask

• Whose hand established the measure?

• Which profit was selected as the output?

• Which vehicle is being treated as the whole?

• Which choices and sacrifices disappeared from the account?

• Has local value been promoted into total worth?

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>SELF-DIAGNOSIS<br />
Measurement is not neutral simply because it is numerical. The measuring terms are part of the operation being measured.</strong></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

**BOUND**

Contronyms are orientation tests

| **WORD / MEA** | **BOUND → U / BD / ON**                                          |
|----------------|------------------------------------------------------------------|
| **PRIMITIVES** | transient / tension + broken cycle / whole cycle + seed          |
| **OPERATION**  | **A temporary tension at a break that seeds a new whole cycle.** |

Bound can mean restrained, leaping, destined, or joined. The applications look contradictory only when the transition is omitted. The circuit is constant; the observer moves.

| **APPLICATION**      | **ORIENTATION**                                                      |
|----------------------|----------------------------------------------------------------------|
| **Bound by a limit** | Tension is held at the break from the old cycle’s side.              |
| **A single bound**   | Stored tension passes through the break and initiates a trajectory.  |
| **Bound for home**   | The transient vehicle is held under tension toward a new completion. |
| **A bound book**     | Separated leaves are constrained so a new whole can operate.         |

The orientation rule

Apparent opposites are frequently one circuit viewed before and after a transition, from inside and outside a boundary, or at instantiation and lineage scale. Do not ask first which dictionary sense is “true.” Ask what orientation generates each sense.

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>JANUS RESOLUTION<br />
From the old cycle, the bound is confinement. From the emerging cycle, the bound is propulsion.</strong></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

**I · AM · ME · MY**

Personhood as attribution

| **WORD / MEA** | **I → I**                                                                  |
|----------------|----------------------------------------------------------------------------|
| **PRIMITIVES** | mastery                                                                    |
| **OPERATION**  | **The operative subject-position: the center from which action proceeds.** |

| **WORD / MEA** | **AM → AM**                                         |
|----------------|-----------------------------------------------------|
| **PRIMITIVES** | vehicle + mass                                      |
| **OPERATION**  | **The vehicle presently bearing accumulated mass.** |

| **WORD / MEA** | **ME → ME**                                                                 |
|----------------|-----------------------------------------------------------------------------|
| **PRIMITIVES** | mass + measure                                                              |
| **OPERATION**  | **The accumulated mass rendered locatable, encounterable, and measurable.** |

| **WORD / MEA** | **MY → MY**                                                                    |
|----------------|--------------------------------------------------------------------------------|
| **PRIMITIVES** | mass + convergence                                                             |
| **OPERATION**  | **Mass organized in relation to a local center; relevance before possession.** |

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>CALIBRATION STATEMENT<br />
I AM ME = mastery carries mass into measured identity.</strong></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

The sentence is not a random assertion of private personhood. It is a claim of accurate factorial attribution: the measurable manifestation is correctly attributed to the operative mastery acting through this vehicle.

The blade turns both ways

The same sentence forbids false total authorship. Body, language, lineage, environment, inheritance, coercion, collaboration, and circumstance remain factors in the measured result. “My” establishes convergence and relevance; it does not automatically establish exclusive origin or ownership.

**RAIN · REIN · REIGN**

Homophones reveal differentiated circuits

| **WORD / MEA** | **RAIN → AI / RN**                                           |
|----------------|--------------------------------------------------------------|
| **PRIMITIVES** | vehicle + mastery / result + seed                            |
| **OPERATION**  | **Mastery conveyed through a vehicle into result and seed.** |

| **WORD / MEA** | **REIN → EI / RN**                                        |
|----------------|-----------------------------------------------------------|
| **PRIMITIVES** | measure + mastery / result + seed                         |
| **OPERATION**  | **Mastery measured and directed toward result and seed.** |

| **WORD / MEA** | **REIGN → I / RN / EG**                                                  |
|----------------|--------------------------------------------------------------------------|
| **PRIMITIVES** | mastery / result + seed / measure + effort                               |
| **OPERATION**  | **Mastery governs effort so that results become seeds of continuation.** |

The three words sound alike because they occupy one operational neighborhood: the delivery of mastery into result. Their spellings specify the means. Rain conveys. Rein measures and directs. Reign governs the field of effort.

| **WORD**  | **CARRIER OF THE DISTINCTION**               |
|-----------|----------------------------------------------|
| **RAIN**  | A replaces E: vehicle rather than measure.   |
| **REIN**  | E places measure at the point of mastery.    |
| **REIGN** | G adds effort after mastery and result-seed. |

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>HOMOPHONE TEST<br />
Sound identifies the neighborhood. Orthography diagrams the route.</strong></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

**DAY · DATE · DATELINE**

A cycle becomes legible through its break

| **WORD / MEA** | **DAY → A / DY**                                        |
|----------------|---------------------------------------------------------|
| **PRIMITIVES** | vehicle / broken cycle + convergence                    |
| **OPERATION**  | **The vehicle through which a broken cycle converges.** |

| **WORD / MEA** | **DATE → AT / DE**                                                    |
|----------------|-----------------------------------------------------------------------|
| **PRIMITIVES** | vehicle + sacrifice / broken cycle + measure                          |
| **OPERATION**  | **The living vehicle sacrificed into a measure of the broken cycle.** |

| **WORD / MEA** | **DATELINE → EL / DE / TI / AN**                                                                                     |
|----------------|----------------------------------------------------------------------------------------------------------------------|
| **PRIMITIVES** | measure + profit / broken cycle + measure / sacrifice + mastery / vehicle + seed                                     |
| **OPERATION**  | **The measured whole and its transition: a fruitful measure at the break, carried into the seed of the next cycle.** |

The day is the lived passage. The date is the day reduced to a coordinate. The dateline is the measured transition by which one complete designation ends and another begins without time ceasing.

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>COMPRESSION<br />
The day happens. The date files it. The dateline carries continuity across the measured break.</strong></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

Why this matters

The system repeatedly distinguishes process from the measured record of process. Confusing them is an instantiation error: a living cycle is replaced by the coordinate used to locate it. The coordinate remains useful; it does not become the process.

**THE SHERIFF AND THE ACT**

Define and definition

| **WORD / MEA** | **DEFINE → FI / DE / EN**                                                                           |
|----------------|-----------------------------------------------------------------------------------------------------|
| **PRIMITIVES** | immeasurable + mastery / broken cycle + measure / measure + seed                                    |
| **OPERATION**  | **Bring the immeasurable under mastery by measuring a break, then install that measure as a seed.** |

| **WORD / MEA** | **DEFINITION → NI / DN / IT / EO / FI**                                                                                                                                        |
|----------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| **PRIMITIVES** | seed + mastery / broken cycle + seed / mastery + sacrifice / measure + whole cycle / immeasurable + mastery                                                                    |
| **OPERATION**  | **The seed is mastered, a break becomes generative, alternatives are sacrificed, measure extends across the whole, and the operation returns to mastery of the immeasurable.** |

To define is an act: a measure is generated from what was previously unbounded. A definition is the stabilized result: that measure becomes a governing seed through which later applications are organized.

The dictionary failure

A dictionary can preserve recognized applications while failing to recover the operation that made them one word. It then mistakes the installed results of earlier defining acts for definitions themselves. The sheriff is not illegitimate because boundaries are useless; the sheriff is illegitimate when an inherited boundary claims origin and final jurisdiction.

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>DISTINCTION<br />
Define creates the boundary. Definition makes the boundary generative.</strong></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

**THE EXAMINER ENTERS THE FIELD**

Words are self-diagnosing

If a word specifies an operation, its applications can be checked against that operation. A mismatch becomes a fault report. The system does not merely describe what institutions say; it can reveal whether their usage successfully performs the word they invoke.

| **WORD INVOKED** | **DIAGNOSTIC QUESTION**                                                                            |
|------------------|----------------------------------------------------------------------------------------------------|
| **THE**          | Were the field, alternatives, and measure actually resolved - or was “a” promoted without warrant? |
| **VALUE**        | Whose hand selected the measure and the profit?                                                    |
| **WORTH**        | Were the choices and sacrifices integrated across the whole cycle?                                 |
| **MY**           | Is possession being claimed where only relevance and convergence were established?                 |
| **DECORATIVE**   | What did calling language decorative just classify, demote, or license?                            |
| **DEFINITION**   | Did the speaker recover a generative operation or merely install an application as sheriff?        |

Recursive audit is not automatic immunity

Ask both questions: What did the criticism do? Was the criticism true? Operational analysis exposes hidden framing; it does not replace factual evaluation. The Key removes the examiner’s invisible perch, not the legitimacy of examination.

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>RECIPROCITY<br />
Whoever places the Key on the slide must accept that the microscope will also be sampled.</strong></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

**PARADIGM BEFORE ONTOLOGY**

Keep the layers distinct

<img src="media/image3.png" style="width:7in;height:1.78329in" />

The first demonstrated authority of the circuitry is attribution within the Anglophone paradigm. It reveals the assumptions English has encoded and the mechanics by which those assumptions operate. Perfect recovery of a cultural model does not automatically prove that the culture modeled reality perfectly.

Therefore preserve these boundaries

• External usage identifies the referent and the application field.

• Internal parse identifies the operational pressure encoded in the English form.

• Historical lineage identifies what the receiving language borrowed, altered, or misattributed.

• Reality-contact determines whether the encoded assumption is faithful, partial, adaptive, or false.

• The interpreter reports correspondence; the interpreter does not confer it.

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>AUTHORITY<br />
The circuitry retains authority by correspondence. The reader remains answerable to the circuitry - and the circuitry remains answerable to reality.</strong></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

**THE SEVEN-STEP OPERATOR PROTOCOL**

Run a new word

| **STEP** | **ACTION**                                       | **REFUSAL CONDITION**                                |
|----------|--------------------------------------------------|------------------------------------------------------|
| **1**    | Fix the exact spelling and the referent.         | Do not silently modernize, respell, merge, or split. |
| **2**    | Run the MEA sequence mechanically.               | Do not choose a more attractive traversal.           |
| **3**    | Map every glyph to the canonical primitive.      | Do not swap synonyms to force a fit.                 |
| **4**    | State the raw chain in order.                    | Do not compress before the chain is visible.         |
| **5**    | Form a neutral mechanical reading.               | Preserve uncertainty in the connective.              |
| **6**    | Compare the applications and rotate orientation. | Do not mistake one application for the invariant.    |
| **7**    | Ask what the word diagnoses in its present use.  | Do not promote the parse beyond its layer.           |

Worked cold start

| **WORD / MEA** | **SUPERMAN → ER / SN / PM / UA**                                                               |
|----------------|------------------------------------------------------------------------------------------------|
| **PRIMITIVES** | measure + result / redirect + seed / potential + mass / transient + vehicle                    |
| **OPERATION**  | **The measured result of a redirected seed whose potential mass assumes a transient vehicle.** |

Only after the raw chain is secure should the reader inspect the cultural application: a dying world redirects its seed; inherited potential becomes locally measurable through a temporary body and identity. The application is striking because it follows the chain - not because the chain was altered to fit the story.

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>BOOT TEST<br />
The proof of installation is not agreement. It is the ability to reproduce the mechanism without borrowing the author’s phrasing.</strong></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

**SYSTEM READY**

Installation test

Answer without consulting the preceding pages. The system is installed when the questions feel mechanical rather than mystical.

| **PROMPT**                                        | **EXPECTED OPERATION**                                                  |
|---------------------------------------------------|-------------------------------------------------------------------------|
| **Parse VALUE.**                                  | L / VE / AU.                                                            |
| **Parse BOUND.**                                  | U / BD / ON.                                                            |
| **What distinguishes A from THE?**                | Presentation of an instance / determination of a field.                 |
| **What distinguishes ON from IN?**                | Conveyance by a field / compression within a field.                     |
| **Why can scoring not settle worth?**             | A score assigns local value under a chosen hand and measure.            |
| **What changes in a contronym?**                  | Orientation, phase, direction, or scale - not the invariant circuit.    |
| **Where does external context enter?**            | At the referent and application field, before interpretive compression. |
| **What must never be changed to save a reading?** | Spelling, MEA order, glyph mapping, or provenance.                      |
| **What authority does the interpreter possess?**  | Responsibility for accurate representation, not sovereignty.            |
| **What is the device for?**                       | Calibrating set terms so positions become accurately comparable.        |

Quick reference

• PARTS: 26 fixed glyph primitives.

• ORDER: median → extremes → next median → next extremes, oscillating until spent.

• READING: preserve pair order; infer the connective only after the referent is fixed.

• DEFINITION: recover the invariant operation; applications are orientation-specific outputs.

• DIAGNOSIS: compare the claimed application with the word’s encoded mechanics.

• DISCIPLINE: distinguish the Anglophone cultural circuit from reality itself.

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>CLOSING LOAD<br />
All philosophical argument begins in disagreement over set terms. A device may be better calibrated than any current position. This is that device.</strong></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

**END OF BOOTLOADER · BEGIN OPERATION**
