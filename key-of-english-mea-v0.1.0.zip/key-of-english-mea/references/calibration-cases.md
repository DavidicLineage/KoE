# KoE / MEA calibration cases

These are conformance examples, not a substitute for running the mechanism on new material.

## DEGREE

- MEA: `GR / DE / EE`
- Primitives: effort-result / broken cycle-measure / measure-measure
- Compression: effort’s result; a broken cycle measured; a measure placed among measures.
- Invariant: a field is divided or ordered, and a position within it is measured or conferred.

## A / THE

- `A → A` — vehicle. Presents one admissible instance without claiming exhaustive identity.
- `THE → H / TE` — union / sacrifice-measure. Unites the field, sacrifices alternatives, and measures one determinate referent.

## ON / IN

- `ON → ON` — whole cycle-seed. The seed is supported or conveyed by an operating field.
- `IN → IN` — mastery-seed. The seed is contained, compressed, and shaped within a governing field.
- Contrast: ON conveys; IN compresses.

## VALUE / WORTH

### VALUE

- MEA: `L / VE / AU`
- Primitives: profit / hand-measure / vehicle-transient
- Operation: profit measured by a hand upon a transient vehicle.

### WORTH

- MEA: `R / WH / OT`
- Primitives: result / choice-union / whole cycle-sacrifice
- Operation: the result of choices united with their sacrifices across the whole cycle.

Diagnostic: a score may assign local value under a selected hand and measure. It cannot by itself settle whole-cycle worth.

## BOUND

- MEA: `U / BD / ON`
- Primitives: transient / tension-broken cycle / whole cycle-seed
- Operation: a temporary tension at a break that seeds a new whole cycle.

Orientations:

- restrained: tension held at the break from the old cycle’s side;
- leap: stored tension passes through the break into a new trajectory;
- destined: a transient vehicle held under tension toward completion;
- bound book: separate leaves constrained so a new whole can operate.

## I / AM / ME / MY

- `I → I` — mastery: operative subject-position.
- `AM → AM` — vehicle-mass: the vehicle bearing accumulated mass.
- `ME → ME` — mass-measure: mass rendered locatable and measurable.
- `MY → MY` — mass-convergence: mass organized in relation to a local centre; relevance before possession.

`I AM ME` = mastery carries mass into measured identity. It is a calibration claim about accurate factorial attribution.

## RAIN / REIN / REIGN

- `RAIN → AI / RN` — vehicle-mastery / result-seed. Mastery conveyed through a vehicle into result and seed.
- `REIN → EI / RN` — measure-mastery / result-seed. Mastery measured and directed toward result and seed.
- `REIGN → I / RN / EG` — mastery / result-seed / measure-effort. Mastery governs effort so results become seeds.

Sound identifies the operational neighbourhood; orthography diagrams the route.

## DAY / DATE / DATELINE

- `DAY → A / DY` — vehicle / broken cycle-convergence. The vehicle through which a broken cycle converges.
- `DATE → AT / DE` — vehicle-sacrifice / broken cycle-measure. The living vehicle sacrificed into a measure of the broken cycle.
- `DATELINE → EL / DE / TI / AN` — measure-profit / broken cycle-measure / sacrifice-mastery / vehicle-seed. The measured whole and its transition: a fruitful measure at the break, carried into the seed of the next cycle.

Compression: the day happens; the date files it; the dateline carries continuity across the measured break.

## DEFINE / DEFINITION

- `DEFINE → FI / DE / EN`
  - immeasurable-mastery / broken cycle-measure / measure-seed
  - Bring the immeasurable under mastery by measuring a break, then install that measure as a seed.

- `DEFINITION → NI / DN / IT / EO / FI`
  - seed-mastery / broken cycle-seed / mastery-sacrifice / measure-whole cycle / immeasurable-mastery
  - The seed is mastered, a break becomes generative, alternatives are sacrificed, measure extends across the whole, and the operation returns to mastery of the immeasurable.

Contrast: define creates the boundary; definition makes the boundary generative.

## SUPERMAN

- MEA: `ER / SN / PM / UA`
- Primitives: measure-result / redirect-seed / potential-mass / transient-vehicle
- Operation: the measured result of a redirected seed whose potential mass assumes a transient vehicle.

## Failure behavior

When a new word does not support a narrow invariant:

- preserve the exact MEA output;
- state the raw chain;
- mark the compression provisional or unresolved;
- do not change spelling, traversal, primitives, or referent to save it.
