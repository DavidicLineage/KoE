# Key of English / MEA Agent Skill

This is a portable Agent Skills package for installing the Key of English and deterministic Median-Extremes Alternation workflow in a compatible AI agent.

## What is inside

- `SKILL.md` — the agent's operating instructions and trigger description.
- `scripts/mea_parse.py` — deterministic MEA parser; interpretation cannot reorder the word.
- `scripts/conformance.py` — exact checks against published calibration cases.
- `references/canonical-system.md` — fixed glyph table, algorithm, orientation, layers.
- `references/calibration-cases.md` — worked canonical examples.
- `references/bootloader.md` — the complete human bootloader.
- `assets/KoE_MEA_Bootloader_v0.1.pdf` — formatted bootloader for human readers.

## Use it

The folder itself is the skill. Keep the folder name exactly `key-of-english-mea`.

### Compatible agent / project folder

Place the folder at:

```text
.agents/skills/key-of-english-mea/
```

For a user-wide Codex installation, place it at:

```text
$HOME/.agents/skills/key-of-english-mea/
```

Restart the agent if it does not appear immediately. Invoke it explicitly as `$key-of-english-mea`, or ask naturally:

```text
Use the Key of English skill. Slice down VALUE and WORTH.
```

### OpenAI API hosted skill

The supplied ZIP contains one top-level folder and is ready for upload as an Agent Skill bundle. No repackaging is required.

## Quick local check

From inside the skill folder:

```bash
python scripts/conformance.py
python scripts/mea_parse.py "I AM ME"
python scripts/mea_parse.py --json "RAIN REIN REIGN"
```

## Version

Working implementation v0.1.0, based on *Key of English: MEA Bootloader* v0.1, July 2026.
